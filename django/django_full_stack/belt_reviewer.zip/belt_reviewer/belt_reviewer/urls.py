from django.urls import path, include

urlpatterns = [
    path('', include('belt_reviewer_app.urls'))
]
