from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('logout', views.logout),
    path('dashboard', views.dashboard),
    path('add_item', views.add_item),
    path('create_item', views.create_item),
    path('add/<int:itemId>', views.fav_item),
    path('remove/<int:itemId>', views.unfav_item),
    path('delete_item/<int:itemId>', views.delete_item),
    path('wish_items/<int:itemId>', views.show_item),
]
