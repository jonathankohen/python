from django.shortcuts import render, redirect
from .models import User, Item
from django.contrib import messages
import bcrypt
from django.db.models import Q


def index(request):
    return render(request, 'index.html')


def register(request):
    print(request.POST)
    validationErrors = User.objects.regValidator(request.POST)
    if len(validationErrors) > 0:
        for value in validationErrors.values():
            messages.error(request, value)
        return redirect("/")
    else:
        pw_hash = bcrypt.hashpw(
            request.POST['pw'].encode(), bcrypt.gensalt()).decode()
        newUser = User.objects.create(
            name=request.POST['name'], username=request.POST['username'], password=pw_hash)
        request.session['loggedInId'] = newUser.id
        return redirect("/dashboard")


def login(request):
    print(request.POST)
    validationErrors = User.objects.loginValidator(request.POST)
    if len(validationErrors) > 0:
        for value in validationErrors.values():
            messages.error(request, value)
        return redirect("/")
    else:
        print(validationErrors)
        username_filter = User.objects.filter(
            username=request.POST['username'])
        request.session['loggedInId'] = username_filter[0].id
        return redirect("/dashboard")


def logout(request):
    request.session.clear()
    return redirect("/")


def dashboard(request):
    if 'loggedInId' not in request.session:
        messages.error(request, "You must log in to see the dashboard.")
        return redirect("/")
    context = {
        'loggedinuser': User.objects.get(id=request.session['loggedInId']),
        'favorites': Item.objects.filter(Q(favorites=User.objects.get(id=request.session['loggedInId'])) | Q(uploader=User.objects.get(id=request.session['loggedInId']))),
        'not_favorites': Item.objects.exclude(Q(favorites=User.objects.get(id=request.session['loggedInId'])) | Q(uploader=User.objects.get(id=request.session['loggedInId'])))
    }
    return render(request, "dashboard.html", context)


def add_item(request):
    return render(request, "add_item.html")


def create_item(request):
    print(request.POST)
    validationErrors = Item.objects.itemValidator(request.POST)
    if len(validationErrors) > 0:
        for value in validationErrors.values():
            messages.error(request, value)
        return redirect("/wish_items/create")

    new_item = Item.objects.create(name=request.POST['item_name'], uploader=User.objects.get(
        id=request.session['loggedInId']))
    return redirect("/dashboard")


def show_item(request, itemId):
    context = {
        'itemObj': Item.objects.get(id=itemId)
    }
    return render(request, "show_item.html", context)


def fav_item(request, itemId):
    print(request.POST)
    user = User.objects.get(id=request.session['loggedInId'])
    item = Item.objects.get(id=itemId)
    item.favorites.add(user)
    return redirect("/dashboard")


def unfav_item(request, itemId):
    print(request.POST)
    user = User.objects.get(id=request.session['loggedInId'])
    item = Item.objects.get(id=itemId)
    item.favorites.remove(user)
    return redirect("/dashboard")


def delete_item(request, itemId):
    item = Item.objects.get(id=itemId)
    item.delete()
    return redirect("/dashboard")
