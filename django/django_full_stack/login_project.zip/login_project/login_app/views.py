from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User
import bcrypt


def index(req):
    return render(req, 'index.html')


def register(req):
    errors = User.objects.reg_validator(req.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(req, value)
        return redirect("/")
    else:
        password = req.POST.get('password', 'password')
        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        new_user = User.objects.create(first_name=req.POST.get(
            'first_name', 'first_name'), last_name=req.POST.get(
            'last_name', 'last_name'), email=req.POST.get(
            'email', 'email'), password=pw_hash)
        req.session['logged_in_id'] = new_user.id
        return redirect("/success")


def login(req):
    errors = User.objects.login_validator(req.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(req, value)
        return redirect("/")
    else:
        user = User.objects.filter(
            email=req.POST.get('email', 'email'))
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(req.POST.get('password', 'password').encode(), logged_user.password.encode()):
                req.session['logged_in_id'] = logged_user.id
                return redirect('/success')
    return redirect("/")


def success(req):
    context = {
        "loggedInUser": User.objects.get(id=req.session['logged_in_id'])
    }
    return render(req, 'success.html', context)


def logout(req):
    try:
        del req.session['logged_in_id']
    except:
        print("No user logged in.")
    return redirect("/")
