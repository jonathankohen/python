from django.urls import path, include

urlpatterns = [
    path('', include('shows_app.urls')),
]
