from django.db import models


class Show(models.Model):
    title = models.CharField(max_length=45)
    network = models.CharField(max_length=15)
    release_date = models.CharField(max_length=10)
    desc = models.TextField("Show description")
