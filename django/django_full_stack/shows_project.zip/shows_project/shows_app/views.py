from django.shortcuts import render, redirect
from .models import Show


def root(req):
    return redirect('/shows')


def index(req):
    return render(req, 'index.html')


def create(req):
    print(req.POST)
    new_show = Show.objects.create(title=req.POST.get('title', 'Title'), network=req.POST.get(
        'network', 'network'), release_date=req.POST.get('release_date', 'Release Date'), desc=req.POST.get('desc', 'Description'))

    return redirect(f'/shows/{new_show.id}')


def single_show(req, idShow):
    context = {
        "show": Show.objects.get(id=idShow)
    }
    return render(req, 'single_show.html', context)


def shows(req):
    context = {
        "all_shows": Show.objects.all()
    }
    return render(req, 'shows.html', context)


def edit(req, idShow):
    context = {
        "show": Show.objects.get(id=idShow)
    }
    return render(req, 'edit.html', context)


def delete(req, idShow):
    show = Show.objects.get(id=idShow)
    show.delete()
    return redirect("/shows")


def update(req, idShow):
    show = Show.objects.get(id=idShow)
    show.title = req.POST.get("title", "Title")
    show.network = req.POST.get("network", "Network")
    show.release_date = req.POST.get("release_date", "Release Date")
    show.desc = req.POST.get("desc", "Description")
    show.save()
    return redirect(f'/shows/{idShow}')
