from django.apps import AppConfig


class ShowsAppConfig(AppConfig):
    name = 'shows_app'
