from django.shortcuts import render, redirect


def index(req):
    if "counter" in req.session:
        req.session["counter"] += 1
    else:
        req.session["counter"] = 1
    return render(req, 'index.html')


def destroy_session(req):
    if "counter" in req.session:
        req.session["counter"] = 0
    return redirect('/')


# def index(req):
#     counter = req.session.get('counter')

#     if "counter" in req.session:
#         counter += 1
#     else:
#         counter = 1
#     return render(req, 'index.html')


# def destroy_session(req):
#     counter = req.session.get('counter')

#     if "counter" in req.session:
#         counter = 0
#     return redirect('/')
